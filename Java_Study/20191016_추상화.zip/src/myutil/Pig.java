package myutil;

public class Pig extends Animal {

	@Override
	public void cry() {
		System.out.println("�ܲ�");
		
	}

	@Override
	public void eat() {
		System.out.println("�ܲ�����");
		
	}
	
	
	

}
