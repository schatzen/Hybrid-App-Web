package myutil;

public class Dog extends Animal {

	@Override
	public void cry() {
		System.out.println("�۸�");
		
	}

	@Override
	public void eat() {
		System.out.println("����");
		
	}
	
	
}
