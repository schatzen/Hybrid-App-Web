package myutil;

public class Cat extends Animal {

	@Override
	public void cry() {
		System.out.println("�Ŀ�");
		
	}
	@Override
	public void eat() {
		System.out.println("��");
		
	}
	
	

}