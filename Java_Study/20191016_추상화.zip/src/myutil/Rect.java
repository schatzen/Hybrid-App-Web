package myutil;

public class Rect extends Shape{

	@Override
	public void draw() {
		System.out.println("��");
		
	}
	
	
	

}
