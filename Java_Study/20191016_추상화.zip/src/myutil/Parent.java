package myutil;

public class Parent {
	
	public void hi() {
		System.out.println("---�ȳ��ϼ�---");
	}

	public void sub() {
		System.out.println("--Parent.sub() call--");
	}

	public void sub(int n) {
		System.out.println("--Parent.sub(int n) call--" );

	}
	
	
	

}
