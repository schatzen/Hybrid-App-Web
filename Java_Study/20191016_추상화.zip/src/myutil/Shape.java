package myutil;

public abstract class Shape {
	
	abstract public void draw();
	

}
