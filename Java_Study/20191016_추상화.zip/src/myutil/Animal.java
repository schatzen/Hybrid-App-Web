package myutil;

public abstract class Animal {

	abstract public void cry();

	abstract public void eat();

}
