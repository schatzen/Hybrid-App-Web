package test;

public class TestDao {

}
