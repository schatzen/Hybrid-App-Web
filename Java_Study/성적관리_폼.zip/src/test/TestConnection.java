package test;

import java.sql.Connection;

import service.DBService;

public class TestConnection {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		while(true)
		{
			Connection conn = DBService.getInstance().getConnection();
			//Connection conn = new DBService().getConnection();
			System.out.println("--success--");
			conn.close();
			
			Thread.sleep(1000);
		}
		
		
	}

}
