package mymain;

public class MyMain_Wrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//auto-boxing
		Integer nob1 = 10; // 10 > new Integer(10)
		
		Integer nob2 = new Integer(100);
		
		int n = nob2;		//	nob2.intValue();
		double d = nob2;	//	nob2.doubleValue();
		float f = nob2;		//	nob2.floatValue();

	}

}
