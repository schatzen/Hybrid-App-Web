package myutil;

public interface RemoteCon extends Volume,Channel {

	void onOff();

}
