
public class Jumin {

}
